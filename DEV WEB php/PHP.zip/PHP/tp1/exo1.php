#!/usr/bin/php script.php

Bonjour on va écrire du php.

<?php
$nb = 1;

var_dump($nb);

var_dump($argv); // arguments de la cli




?>