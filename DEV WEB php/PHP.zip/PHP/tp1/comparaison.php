

<?php
$x = 10;
$y = 5;

$is_equal = $x == $y;
$is_not_equal = $x != $y;
$is_greater = $x > $y;
$is_less = $x < $y;
$is_greater_or_equal = $x >= $y;
$is_less_or_equal = $x <= $y;

var_dump($is_equal);
var_dump($is_not_equal);
var_dump($is_greater);
var_dump($is_less);
var_dump($is_greater_or_equal);
var_dump($is_less_or_equal);

?>