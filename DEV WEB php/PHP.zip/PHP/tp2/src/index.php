<?php
$data = json_decode(file_get_contents("../data/data.json"), true);
$brand = $_GET['brand'] ?? null;
?>

<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8">
        <title>Liste des produits</title>
        <link rel="stylesheet" href="../static/style.css">
    </head>
    <body>
        <nav>
            <a href="?brand=Apple">Voir les produits Apple</a> |
            <a href="index.php">Voir tous les produits</a>
        </nav>
        <hr>
        <?php if (!empty($data)): ?>
            <?php foreach ($data as $product): ?>
                <?php if ($brand && strtolower($product['brand']) !== strtolower($brand)) continue; ?>
                <div class="product">
                    <h3><?= htmlspecialchars($product['title']) ?></h3>
                    <p>Marque : <?= htmlspecialchars($product['brand']) ?></p>
                    <p>Prix : <?= htmlspecialchars($product['price']) ?> €</p>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Aucun produit trouvé.</p>
        <?php endif; ?>
    </body>
</html>